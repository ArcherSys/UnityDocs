WindowsPhoneUnityConnection is an example project that shows how to communicate between Unity and Windows Phone.

It has been tested with 04-15 build.

To run example project:
- Open Export\WindowsPhoneUnityConnection.sln solution with Visual Studio 2012
- Connect your phone to PC and make sure device is unlocked
- Build and run example project

MyPlugin reports memory usage. There are two separate projects with identical classes and interfaces. One is used when project runs in the Editor and another one when project runs on Windows Phone device.

MainScript exposes ButtonClicked event which gets fired when Unity button is clicked. Click count is tracked on Windows Phone side and is displayed using XAML TextBlock control.

Finally XAML Slider control can be used to rotate cube inside Unity. Please note that XAML controls can only be accessed from UI thread by using Dispatcher object. Likewise Unity objects can only be accessed from Unity thread. UnityApp.BeginInvoke method must be used to achieve this.
