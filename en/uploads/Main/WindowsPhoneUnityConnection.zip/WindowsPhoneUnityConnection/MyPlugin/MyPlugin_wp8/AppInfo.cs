﻿using Microsoft.Phone.Info;

namespace MyPlugin
{
	public static class AppInfo
	{
		#region Properties

		public static int AvailableMemory
		{
			get { return (int)(DeviceStatus.ApplicationMemoryUsageLimit / 1024 / 1024); }
		}

		public static int UsedMemory
		{
			get { return (int)(DeviceStatus.ApplicationCurrentMemoryUsage / 1024 / 1024); }
		}

		#endregion
	}
}
