﻿namespace MyPlugin
{
	public static class AppInfo
	{
		#region Properties

		public static int AvailableMemory
		{
			get { return 0; }
		}

		public static int UsedMemory
		{
			get { return 0; }
		}

		#endregion
	}
}
